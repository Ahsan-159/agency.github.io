jQuery(document).ready(function(){
    jQuery(".owl-carousel").owlCarousel();
  });